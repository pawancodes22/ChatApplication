import React from "react";
import styled from "styled-components";
import Logout from "./Logout";
import ChatInput from "./ChatInput";
import Messages from "./Messages";
import axios from "axios";
import { endpoints } from "../utils/endpoints";
import { ToastContainer, toast, Bounce } from "react-toastify";
import loader from "../assets/loader.gif";
import "react-toastify/dist/ReactToastify.css";
export default function ChatContainer({ currentChat, currentUser }) {
  const toastOptions = {
    position: "bottom-right",
    autoClose: 5000,
    hideProgressBar: false,
    closeOnClick: false,
    pauseOnHover: true,
    draggable: true,
    progress: undefined,
    theme: "dark",
    transition: Bounce,
  };
  const handleSendMessage = async (msg) => {
    const sendMsgJSON = {
      from: currentUser._id,
      to: currentChat._id,
      msg,
    };
    console.log("sendMsgJSON", sendMsgJSON);
    const response = await axios.post(
      endpoints.addMessageEndpoint,
      sendMsgJSON
    );
    if (response.data.status) {
      toast.success(response.data.msg, toastOptions);
    } else {
      toast.error("Couldnt send msg!", toastOptions);
    }
  };
  return (
    <Container>
      <div className="chat-header">
        <div className="user-details">
          <div className="avatar">
            <img src={currentChat.avatarImage} alt="" />
          </div>
          <div className="username">
            <h3>{currentChat.username}</h3>
          </div>
        </div>
        <Logout />
      </div>
      <Messages />
      <ChatInput handleSendMessage={handleSendMessage} />
    </Container>
  );
}

const Container = styled.div`
  padding-top: 1rem;
  .chat-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0px 2rem;
    .user-details {
      display: flex;
      align-items: center;
      gap: 1rem;
      .avatar {
        img {
          height: 3rem;
        }
        .username {
          h3 {
            color: white;
          }
        }
      }
    }
  }
`;
